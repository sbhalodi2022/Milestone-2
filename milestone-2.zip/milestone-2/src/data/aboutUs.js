import about1 from "../assets/images/smit.png";
import about2 from "../assets/images/shriya.png";
import about3 from "../assets/images/vrutik.jpg";

export const aboutsUs = [
  {
    id: 1,
    name: "SMIT PATEL",
    status: "Computer Science",
    img: about1,
  },
  {
    id: 2,
    name: "Shriya Bhalodi",
    status: "Computer Science",
    img: about2,
  },
  {
    id: 3,
    name: "Vrutik Savaliya",
    status: "Computer Science",
    img: about3,
  },
];
